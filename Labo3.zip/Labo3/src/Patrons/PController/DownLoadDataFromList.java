package Patrons.PController;

public interface DownLoadDataFromList {
	public void notifyRecordSize(int index, int recordSize);
}
