package Patrons.PController;

public interface InformationNeeded {
	public double getZoom();
	public double getNewX();
	public double getNewY();
	public String getImageName();
}
