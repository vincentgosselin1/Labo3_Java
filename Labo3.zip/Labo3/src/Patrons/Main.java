package Patrons;

import Patrons.PController.Controller;

public class Main {

	public static void main(String[] args) {
		Controller.start();
	}
}
