package Patrons.PVue;

public interface ObserverIF {
	public void update();
}
